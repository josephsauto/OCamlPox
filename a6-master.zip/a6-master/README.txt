1.       Every n number of seconds a function (signals) will be called

-implement a concurrent thread including Unix.sleepf n and a while loop

- randomly select a country, check to see if the country has been infected or not.

-if infected, then choose p number of countries (I still don’t know how we will   come up with p, maybe based on population and infected rate) increase the infected population of each of these countries


2.Include items in the JSON you can only obtain if you have the number of points
